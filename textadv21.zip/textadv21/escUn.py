# -*- coding: utf-8 -*-
"""
Created on Mon Dec  6 01:58:44 2021

@author: EparatiCoder
"""

class escUn():
    def __init__(self):
        escUn = False
        return escUn
    
    #This Class exists solely as a relic of an attempt to make an escape condition.
    #It is defunct, and unused.